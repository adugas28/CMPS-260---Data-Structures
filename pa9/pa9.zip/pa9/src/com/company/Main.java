// 

package com.company;

import java.util.Scanner;

public class Main {


    // #1
    // This recursive method returns the sum of all the integers from 0 to the
    // positive integer value passed to the parameter n.
    //
    public static int sumPositive(int n) {
        if (n <= 0) {
            return 0;
        } else {
            return sumPositive(n - 1) + n;
        }
    }


    // #2
    // This recursive method returns the sum of all the odd integers from 1 to the
    // positive integer value passed to the parameter n,
    //
    public static int sumOdd(int n) {
        if (n % 2 == 0)
            n--;
        if  (n == 1) {
            return 1;
        } else {
            return sumOdd(n - 2) + n;
        }
    }


    // #3
    // This recursive method squares a number until the result is greater than or
    // equal to 1,000.  It then returns the result.
    //
    public static double squareSails(double d) {
        if (d == 1) {
            return 1;
        }
        if (d >= 1000) {
            return d;
        } else {
            return squareSails(d * d);
        }

    }


    // #4
    // Write a void recursive method that receives a string and a positive integer,
    // then outputs the string the integer number of times.  For example, if the
    // integer is 3 and the string was "Howdy!", the output would be
    //     Howdy!
    //     Howdy!
    //     Howdy!
    //
    // Tip: "return;" may be used in a void method.
    //
    public static void repeatString(int a, String b) {
        if(a == 0) {
            return;
        } else {
            System.out.println(b);
            repeatString(a - 1, b);
        }
    }



    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // input and calls to #1 and #2
        System.out.print("Enter a positive integer value to sum the positive and odd positive integers: ");
        int n = input.nextInt();
        System.out.println("Sum of the positive integers from 0 to " + n + " is " + sumPositive(n));
        System.out.println("Sum of the odd positive integers from 1 to " + n + " is " + sumOdd(n));


        // input and call to #3
        System.out.print("\nEnter a double value to be squared until the result is over 1000: ");
        double d = input.nextInt();
        System.out.println("The result at or past 1,000 by squaring " +  d + " is " + squareSails(d));


        // input and call to #4
        System.out.print("\nEnter the number of times to repeat a message: ");
        int x = input.nextInt();
        System.out.print("Enter a message: ");
        input.nextLine();
        String y = input.nextLine();
        repeatString(x, y);
    }
}
